@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 launch_game.py
  goto end
)
where python >nul 2>nul
if %errorlevel%==0 (
  python launch_game.py
  goto end
)
echo Python is not installed. Install Python 3, then double-click this file again.
echo You can get Python from https://www.python.org/downloads/
pause
:end
