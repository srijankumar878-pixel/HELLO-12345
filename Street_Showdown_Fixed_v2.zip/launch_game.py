from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import webbrowser

folder = Path(__file__).resolve().parent
class QuietHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(folder), **kwargs)

server = ThreadingHTTPServer(('127.0.0.1', 0), QuietHandler)
port = server.server_address[1]
url = f'http://127.0.0.1:{port}/street_showdown_glb.html'
print('Street Showdown is starting...')
print('Game URL:', url)
print('Keep this window open while playing. Press Ctrl+C to stop the game server.')
webbrowser.open(url)
try:
    server.serve_forever()
except KeyboardInterrupt:
    print('\nGame server stopped.')
finally:
    server.server_close()
