STREET SHOWDOWN - FIXED LAUNCHER

1. Extract the ENTIRE ZIP into one normal folder (do not open the HTML from inside the ZIP).
2. Keep these files together: street_showdown_glb.html, exported-model.glb, launch_game.py, START_STREET_SHOWDOWN.bat.
3. Double-click START_STREET_SHOWDOWN.bat.
4. It should open Street Showdown in Chrome or Edge automatically.
5. Keep the black command window open while playing. Close it or press Ctrl+C to stop the local server.

IMPORTANT:
- Do not double-click the HTML file directly. It must be opened through the launcher so the GLB model can load.
- Internet is needed for the Three.js 3D engine (jsDelivr CDN).
- Python 3 must be installed for the launcher. If the launcher says Python is missing, install Python 3 and try again.
- If the game page appears but 3D graphics do not, update Chrome/Edge and turn on hardware acceleration.

Controls are shown on the game screen.
